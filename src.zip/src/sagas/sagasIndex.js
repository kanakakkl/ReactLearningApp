import { put, takeLatest, all } from 'redux-saga/effects';


function* fetchNews(){
const json = yield fetch("https://demo7673523.mockable.io/newsapi")
                 .then(response => response.json())
     console.log("RESPONSE JSON", json);           
    yield put({type:"NEWS_RECIEVED", json: json.articles})
}

function* actionWatcher(){
    yield takeLatest("GET_NEWS", fetchNews)
}

export default function* rootSaga(){
    yield all([
        actionWatcher(),
    ])
}