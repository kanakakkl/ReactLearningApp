import React from 'react';
import { connect } from 'react-redux';

const imgStyle={
    width: '80%',
    height: 'auto',
    border: '4px solid #fcfcfc',
    borderRadius: '5%'
}

const containerStyle={
  width: '50%',
  margin: '0 auto',
  color: '#000'
}
let newsItem = ({article}) => (
    article ?
    <div style={containerStyle}>
     <h1> {article.title}</h1>
     <img style={imgStyle} src={article.urlToImage} alt="not found"/>
     <p>{article.description}</p>
     <a href={article.url} target="_blank">READ MORE...</a>
    </div>:
    null
)

const mapStateToProps = (state) =>({
    article: state.news
})

newsItem = connect(mapStateToProps, null)(newsItem)

export default newsItem