import React from 'react';
import { connect } from 'react-redux';
import { getNews } from '../actions/actionIndex';

let Button = ({getNews}) => (
    <button onClick={getNews}>Press to get News</button>
)

let mapDispatchToProps = {
    getNews: getNews
}

 Button = connect( null, mapDispatchToProps) (Button);

 export default Button